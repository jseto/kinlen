(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory(require("paypal"));
	else if(typeof define === 'function' && define.amd)
		define("KinlenBooking", ["paypal"], factory);
	else if(typeof exports === 'object')
		exports["KinlenBooking"] = factory(require("paypal"));
	else
		root["KinlenBooking"] = factory(root["paypal"]);
})(window, function(__WEBPACK_EXTERNAL_MODULE_paypal_checkout__) {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/bookings/BookingError.ts":
/*!**************************************!*\
  !*** ./src/bookings/BookingError.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var _bookingErrors = {
    INVALID_DATE: 'The date entered in not correct.',
    BOOKING_NOT_AVAILABLE: 'The selected booking slot is no longer available. Please select another date or time slot.',
    INVALID_COUPON: 'The coupon code is not valid. Please check if you typed it correctly.',
};
var BookingError = /** @class */ (function (_super) {
    __extends(BookingError, _super);
    function BookingError(code) {
        var _this = this;
        var message = _bookingErrors[code];
        if (message) {
            _this = _super.call(this, message) || this;
        }
        else
            _this = _super.call(this, code + ' error description not found') || this;
        return _this;
    }
    return BookingError;
}(Error));
exports.BookingError = BookingError;


/***/ }),

/***/ "./src/bookings/booking-data.ts":
/*!**************************************!*\
  !*** ./src/bookings/booking-data.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var booking_1 = __webpack_require__(/*! ./booking */ "./src/bookings/booking.ts");
var guide_1 = __webpack_require__(/*! ./guide */ "./src/bookings/guide.ts");
var rest_1 = __webpack_require__(/*! ../database/rest */ "./src/database/rest.ts");
var holiday_1 = __webpack_require__(/*! ./holiday */ "./src/bookings/holiday.ts");
var utils_1 = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");
var BookingData = /** @class */ (function () {
    function BookingData() {
    }
    BookingData.getFreeGuide = function (date) {
        var guide = new guide_1.Guide(-1);
        return new Promise(function (resolve) {
            rest_1.Rest.getREST('free_guide/', { date: utils_1.Utils.dateToString(date) }).then(function (data) {
                guide.fromObject(data);
                resolve(guide);
            });
        });
    };
    BookingData.getMonthFreeGuide = function (date) {
        return new Promise(function (resolve) {
            rest_1.Rest.getMonthPeriod('free_guide/', utils_1.Utils.dateToString(date), {}).then(function (data) {
                resolve(rest_1.Rest.buildList(data, function () { return new guide_1.FreeGuide(-1); }));
            });
        });
    };
    BookingData.getMonthBookings = function (restaurantId, date) {
        return new Promise(function (resolve) {
            rest_1.Rest.getMonthPeriod('booking_period/', utils_1.Utils.dateToString(date), { restaurant_id: restaurantId }).then(function (data) {
                resolve(rest_1.Rest.buildList(data, function () { return new booking_1.Booking(-1); }));
            });
        });
    };
    BookingData.getBooking = function (id) {
        // select * from wp_kinlen_booking where id={id}
        var booking = new booking_1.Booking(-1);
        return new Promise(function (resolve) {
            rest_1.Rest.getREST('booking/', { id: id }).then(function (data) {
                booking.fromObject(data[0]);
                resolve(booking);
            });
        });
    };
    BookingData.getBookings = function (queryObject) {
        return new Promise(function (resolve) {
            rest_1.Rest.getREST('booking/', queryObject).then(function (data) {
                resolve(rest_1.Rest.buildList(data, function () { return new booking_1.Booking(-1); }));
            });
        });
    };
    BookingData.setGuideHoliday = function (guideId, date) {
        return this.setHoliday('guide_holiday/', guideId, date);
    };
    BookingData.getGuideHolidays = function (guideId, date) {
        return this.getHolidays('guide_holiday/', guideId, date);
    };
    BookingData.setRestaurantHoliday = function (restaurantId, date) {
        return this.setHoliday('restaurant_holiday/', restaurantId, date);
    };
    BookingData.getRestaurantHolidays = function (restaurantId, date) {
        return this.getHolidays('restaurant_holiday/', restaurantId, date);
    };
    BookingData.getRestaurantMonthHolidays = function (restaurantId, date) {
        return new Promise(function (resolve) {
            rest_1.Rest.getMonthPeriod('restaurant_holiday_period/', utils_1.Utils.dateToString(date), { id: restaurantId }).then(function (data) {
                resolve(rest_1.Rest.buildList(data, function () { return new holiday_1.Holiday(-1); }));
            });
        });
    };
    BookingData.setHoliday = function (endpoint, id, date) {
        return rest_1.Rest.postREST(endpoint, {
            id: id,
            date: utils_1.Utils.dateToString(date)
        });
    };
    BookingData.getHolidays = function (endpoint, id, date) {
        var q = { id: id };
        if (date != undefined) {
            q['date'] = utils_1.Utils.dateToString(date);
        }
        return new Promise(function (resolve) {
            rest_1.Rest.getREST(endpoint, q).then(function (data) {
                resolve(rest_1.Rest.buildList(data, function () { return new holiday_1.Holiday(-1); }));
            });
        });
    };
    return BookingData;
}());
exports.BookingData = BookingData;


/***/ }),

/***/ "./src/bookings/booking-mapper.ts":
/*!****************************************!*\
  !*** ./src/bookings/booking-mapper.ts ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var booking_data_1 = __webpack_require__(/*! ./booking-data */ "./src/bookings/booking-data.ts");
var guide_1 = __webpack_require__(/*! ./guide */ "./src/bookings/guide.ts");
var booking_1 = __webpack_require__(/*! ./booking */ "./src/bookings/booking.ts");
var BookingMapper = /** @class */ (function () {
    function BookingMapper(restaurantId) {
        this._lastBookingMapDate = new Date(0);
        this._restaurantId = restaurantId;
        this._bookingMap = [];
        this._restaurantHolidays = [];
        this._availableGuide = [];
    }
    Object.defineProperty(BookingMapper.prototype, "restaurantId", {
        get: function () {
            return this._restaurantId;
        },
        enumerable: true,
        configurable: true
    });
    BookingMapper.prototype.dayBookingSummary = function (date) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!!this.isAvailMapFresh(date)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.buildBookingMapCache(date)];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2: return [2 /*return*/, this._bookingMap[date.getDate()]];
                }
            });
        });
    };
    /**
     * Get the booking summary for a selected day and time and this restaurant
     * @param  date the date of the required booking
     * @param  hour the hour of the booking
     * @return      the booking or null
     */
    BookingMapper.prototype.bookingSummary = function (date, hour) {
        return __awaiter(this, void 0, void 0, function () {
            var daySummary;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.dayBookingSummary(date)];
                    case 1:
                        daySummary = _a.sent();
                        return [2 /*return*/, daySummary && daySummary[hour]];
                }
            });
        });
    };
    /**
     * Retrieves from the cache wether a restaurant is closed or open on date
     * @param  date the date to check
     * @return      true if the restaurant is closed
     */
    BookingMapper.prototype.restaurantHoliday = function (date) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!!this.isAvailMapFresh(date)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.buildBookingMapCache(date)];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2: return [2 /*return*/, this._restaurantHolidays[date.getDate()]];
                }
            });
        });
    };
    BookingMapper.prototype.availableSeats = function (date, hour) {
        return __awaiter(this, void 0, void 0, function () {
            var booking, holiday, guide;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.bookingSummary(date, hour)];
                    case 1:
                        booking = _a.sent();
                        return [4 /*yield*/, this.restaurantHoliday(date)];
                    case 2:
                        holiday = _a.sent();
                        if (holiday) {
                            return [2 /*return*/, 0];
                        }
                        if (!booking) return [3 /*break*/, 3];
                        return [2 /*return*/, (guide_1.MAX_SEATS_PER_GUIDE - booking.bookedSeats)]; // so check if still have seats available
                    case 3: return [4 /*yield*/, this.availableGuide(date)];
                    case 4:
                        guide = _a.sent();
                        return [2 /*return*/, guide != null ? guide.maxSeats() : 0];
                }
            });
        });
    };
    BookingMapper.prototype.assignGuide = function (date, hour) {
        return __awaiter(this, void 0, void 0, function () {
            var booking, guide;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.bookingSummary(date, hour)];
                    case 1:
                        booking = _a.sent();
                        if (!(booking && (guide_1.MAX_SEATS_PER_GUIDE - booking.bookedSeats))) return [3 /*break*/, 2];
                        return [2 /*return*/, booking.guideId]; // so check if still have seats available
                    case 2: return [4 /*yield*/, this.availableGuide(date)];
                    case 3:
                        guide = _a.sent();
                        return [2 /*return*/, guide != null ? guide.id : -1];
                }
            });
        });
    };
    BookingMapper.prototype.isTimeSlotAvailable = function (date, time, requiredSeats) {
        return __awaiter(this, void 0, void 0, function () {
            var seats;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.availableSeats(date, time)];
                    case 1:
                        seats = _a.sent();
                        return [2 /*return*/, seats >= requiredSeats];
                }
            });
        });
    };
    BookingMapper.prototype.isDayAvailable = function (date, requiredSeats) {
        return __awaiter(this, void 0, void 0, function () {
            var bookingDate, now, daySummary, holiday, i, time, guide;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        bookingDate = new Date(date);
                        now = new Date(Date.now());
                        bookingDate.setHours(17, 0);
                        if (bookingDate <= now) {
                            return [2 /*return*/, false];
                        }
                        return [4 /*yield*/, this.dayBookingSummary(date)];
                    case 1:
                        daySummary = _a.sent();
                        return [4 /*yield*/, this.restaurantHoliday(date)];
                    case 2:
                        holiday = _a.sent();
                        if (holiday) {
                            return [2 /*return*/, false];
                        }
                        if (!Object.keys(daySummary).length) return [3 /*break*/, 3];
                        for (i = 0; i < booking_1.BOOKABLE_TIMES.length; ++i) {
                            time = booking_1.BOOKABLE_TIMES[i];
                            if (typeof daySummary[time] === 'undefined' || (guide_1.MAX_SEATS_PER_GUIDE - daySummary[time].bookedSeats) >= requiredSeats) {
                                return [2 /*return*/, true];
                            }
                        }
                        return [2 /*return*/, false];
                    case 3: return [4 /*yield*/, this.availableGuide(date)];
                    case 4:
                        guide = _a.sent();
                        return [2 /*return*/, guide != null];
                }
            });
        });
    };
    BookingMapper.prototype.getUnavailableDays = function (date, seats) {
        return __awaiter(this, void 0, void 0, function () {
            var days, month, day, available;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        days = [];
                        month = date.getMonth();
                        day = new Date(date);
                        day.setDate(1);
                        _a.label = 1;
                    case 1:
                        if (!(month === day.getMonth())) return [3 /*break*/, 3];
                        return [4 /*yield*/, this.isDayAvailable(day, seats)];
                    case 2:
                        available = _a.sent();
                        if (!available) {
                            days.push(new Date(day));
                        }
                        day.setDate(day.getDate() + 1);
                        return [3 /*break*/, 1];
                    case 3: return [2 /*return*/, days];
                }
            });
        });
    };
    BookingMapper.prototype.invalidateCache = function () {
        this._lastBookingMapDate = new Date(0);
    };
    BookingMapper.prototype.availableGuide = function (date) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!!this.isAvailMapFresh(date)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.buildBookingMapCache(date)];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2: return [2 /*return*/, this._availableGuide[date.getDate()]];
                }
            });
        });
    };
    /**
     * Retrieves the bookings for the month in date and builds the booking map
     * and stores it in local memory for subsequent uses
     * @param  date the date where the month to retrieve bookings is taken
     * @return      a promise of
     */
    BookingMapper.prototype.buildBookingMapCache = function (date) {
        return __awaiter(this, void 0, void 0, function () {
            var i, bookings, holidays, availableGuides;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        for (i = 0; i < 32; i++) {
                            this._bookingMap[i] = [];
                            this._restaurantHolidays[i] = false;
                            this._availableGuide[i] = null;
                        }
                        return [4 /*yield*/, booking_data_1.BookingData.getMonthBookings(this._restaurantId, date)];
                    case 1:
                        bookings = _a.sent();
                        bookings.forEach(function (booking) {
                            var day = booking.date.getDate();
                            var bday = _this._bookingMap[day];
                            if (bday && bday[booking.time]) {
                                _this._bookingMap[day][booking.time].bookedSeats += booking.bookedSeats;
                            }
                            else {
                                _this._bookingMap[day][booking.time] = {
                                    bookedSeats: booking.bookedSeats,
                                    guideId: booking.assignedGuide
                                };
                            }
                        });
                        return [4 /*yield*/, booking_data_1.BookingData.getRestaurantMonthHolidays(this._restaurantId, date)];
                    case 2:
                        holidays = _a.sent();
                        holidays.forEach(function (holiday) {
                            var day = holiday.date.getDate();
                            _this._restaurantHolidays[day] = true;
                        });
                        return [4 /*yield*/, booking_data_1.BookingData.getMonthFreeGuide(date)];
                    case 3:
                        availableGuides = _a.sent();
                        availableGuides.forEach(function (guide) {
                            if (guide.date) {
                                var day = guide.date.getDate();
                                _this._availableGuide[day] = guide;
                            }
                        });
                        this._lastBookingMapDate = new Date(date);
                        return [2 /*return*/];
                }
            });
        });
    };
    BookingMapper.prototype.isAvailMapFresh = function (date) {
        return this._lastBookingMapDate.getMonth() === date.getMonth() && this._lastBookingMapDate.getFullYear() === date.getFullYear();
    };
    return BookingMapper;
}());
exports.BookingMapper = BookingMapper;


/***/ }),

/***/ "./src/bookings/booking-processor.ts":
/*!*******************************************!*\
  !*** ./src/bookings/booking-processor.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var booking_1 = __webpack_require__(/*! ../../src/bookings/booking */ "./src/bookings/booking.ts");
var booking_mapper_1 = __webpack_require__(/*! ../../src/bookings/booking-mapper */ "./src/bookings/booking-mapper.ts");
var restaurant_1 = __webpack_require__(/*! ./restaurant */ "./src/bookings/restaurant.ts");
var rest_1 = __webpack_require__(/*! ../database/rest */ "./src/database/rest.ts");
var coupon_1 = __webpack_require__(/*! ./coupon */ "./src/bookings/coupon.ts");
var utils_1 = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");
var BookingError_1 = __webpack_require__(/*! ../../src/bookings/BookingError */ "./src/bookings/BookingError.ts");
var BookingProcessor = /** @class */ (function () {
    function BookingProcessor(booking) {
        this._rawBooking = booking;
    }
    BookingProcessor.prototype.booking = function () {
        return __awaiter(this, void 0, void 0, function () {
            var restaurant, coupon, beforeDiscount;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!!this._booking) return [3 /*break*/, 4];
                        this._booking = new booking_1.Booking(-1);
                        this._booking.fromObject(this._rawBooking);
                        return [4 /*yield*/, this.restaurant()];
                    case 1:
                        restaurant = _a.sent();
                        return [4 /*yield*/, this.coupon()];
                    case 2:
                        coupon = _a.sent();
                        return [4 /*yield*/, this.beforeDiscount()];
                    case 3:
                        beforeDiscount = _a.sent();
                        this._booking.setCouponValue(coupon.discount(beforeDiscount));
                        this._booking.setAdultPrice(restaurant.adultPrice);
                        this._booking.setChildrenPrice(restaurant.childrenPrice);
                        _a.label = 4;
                    case 4: return [2 /*return*/, this._booking];
                }
            });
        });
    };
    BookingProcessor.prototype.insertTempBooking = function () {
        return __awaiter(this, void 0, void 0, function () {
            var booking, mapper, _a, _b, _c;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0: return [4 /*yield*/, this.booking()];
                    case 1:
                        booking = _d.sent();
                        booking.setPaid(false);
                        booking.setPaidAmount(0);
                        mapper = new booking_mapper_1.BookingMapper(booking.restaurant);
                        return [4 /*yield*/, this.validateBooking()];
                    case 2:
                        if (!_d.sent()) return [3 /*break*/, 5];
                        _b = (_a = booking).setAssignedGuide;
                        return [4 /*yield*/, mapper.assignGuide(booking.date, booking.time)];
                    case 3:
                        _b.apply(_a, [_d.sent()]);
                        _c = this;
                        return [4 /*yield*/, BookingProcessor.insertBooking(booking)];
                    case 4:
                        _c._booking = _d.sent();
                        return [2 /*return*/, this._booking];
                    case 5: return [2 /*return*/, null];
                }
            });
        });
    };
    BookingProcessor.prototype.deleteTempBooking = function () {
        return __awaiter(this, void 0, void 0, function () {
            var booking;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.booking()];
                    case 1:
                        booking = _a.sent();
                        if (!(booking.id >= 0)) return [3 /*break*/, 3];
                        return [4 /*yield*/, BookingProcessor.deleteBooking(booking)];
                    case 2: return [2 /*return*/, _a.sent()];
                    case 3: return [2 /*return*/, false];
                }
            });
        });
    };
    BookingProcessor.prototype.persistTempBooking = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            var booking;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.booking()];
                    case 1:
                        booking = _a.sent();
                        if (!(booking.id >= 0)) return [3 /*break*/, 3];
                        booking
                            .setPaymentId(data.paymentId)
                            .setPaymentProvider(data.paymentProvider)
                            .setPaidAmount(data.paidAmount)
                            .setCurrency(data.currency)
                            .setPaid(true);
                        return [4 /*yield*/, BookingProcessor.updateBooking(booking)];
                    case 2:
                        if (_a.sent()) {
                            return [2 /*return*/, booking];
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/, null];
                }
            });
        });
    };
    BookingProcessor.prototype.totalToPay = function () {
        return __awaiter(this, void 0, void 0, function () {
            var coupon, beforeDiscount;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.coupon()];
                    case 1:
                        coupon = _a.sent();
                        return [4 /*yield*/, this.beforeDiscount()];
                    case 2:
                        beforeDiscount = _a.sent();
                        return [2 /*return*/, beforeDiscount - coupon.discount(beforeDiscount)];
                }
            });
        });
    };
    BookingProcessor.prototype.beforeDiscount = function () {
        return __awaiter(this, void 0, void 0, function () {
            var restaurant, adultTotal, childrenTotal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.restaurant()];
                    case 1:
                        restaurant = _a.sent();
                        adultTotal = restaurant.adultPrice * this._rawBooking.adults;
                        childrenTotal = restaurant.childrenPrice * this._rawBooking.children;
                        return [2 /*return*/, adultTotal + childrenTotal];
                }
            });
        });
    };
    BookingProcessor.prototype.isCouponValid = function () {
        return __awaiter(this, void 0, void 0, function () {
            var c;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this._rawBooking.coupon === '')
                            return [2 /*return*/, true];
                        return [4 /*yield*/, this.coupon()];
                    case 1:
                        c = _a.sent();
                        return [2 /*return*/, c.isValid()];
                }
            });
        });
    };
    BookingProcessor.prototype.validateBooking = function (doThrow) {
        if (doThrow === void 0) { doThrow = false; }
        return __awaiter(this, void 0, void 0, function () {
            var validCoupon, mapper, available;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (utils_1.Utils.isInvalid(this._rawBooking.date)) {
                            if (doThrow)
                                throw new BookingError_1.BookingError('INVALID_DATE');
                            return [2 /*return*/, false];
                        }
                        return [4 /*yield*/, this.isCouponValid()];
                    case 1:
                        validCoupon = _a.sent();
                        if (!validCoupon) {
                            if (doThrow)
                                throw new BookingError_1.BookingError('INVALID_COUPON');
                            return [2 /*return*/, false];
                        }
                        mapper = new booking_mapper_1.BookingMapper(this._rawBooking.restaurant_id);
                        return [4 /*yield*/, mapper.isTimeSlotAvailable(this._rawBooking.date, this._rawBooking.time, this.bookedSeats())];
                    case 2:
                        available = _a.sent();
                        if (!available && doThrow)
                            throw new BookingError_1.BookingError('BOOKING_NOT_AVAILABLE');
                        return [2 /*return*/, available];
                }
            });
        });
    };
    BookingProcessor.prototype.bookedSeats = function () {
        return this._rawBooking.adults + this._rawBooking.children;
    };
    BookingProcessor.prototype.restaurant = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!!this._restaurant) return [3 /*break*/, 2];
                        _a = this;
                        return [4 /*yield*/, BookingProcessor.getRestaurant(this._rawBooking.restaurant_id)];
                    case 1:
                        _a._restaurant = _b.sent();
                        _b.label = 2;
                    case 2: return [2 /*return*/, this._restaurant];
                }
            });
        });
    };
    BookingProcessor.prototype.coupon = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!!this._coupon) return [3 /*break*/, 2];
                        _a = this;
                        return [4 /*yield*/, BookingProcessor.getCoupon(this._rawBooking.coupon)];
                    case 1:
                        _a._coupon = _b.sent();
                        _b.label = 2;
                    case 2: return [2 /*return*/, this._coupon];
                }
            });
        });
    };
    BookingProcessor.getRestaurant = function (restaurantId) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve) {
                        rest_1.Rest.getREST('restaurant/', { id: restaurantId }).then(function (data) {
                            var restaurant = null;
                            if (data[0]) {
                                restaurant = new restaurant_1.Restaurant(-1);
                                restaurant.fromObject(data[0]);
                            }
                            resolve(restaurant);
                        });
                    })];
            });
        });
    };
    BookingProcessor.getCoupon = function (code) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve) {
                        rest_1.Rest.getREST('coupon/', { code: code.toUpperCase() }).then(function (data) {
                            var coupon = new coupon_1.Coupon(-1);
                            if (data[0]) {
                                coupon.fromObject(data[0]);
                            }
                            resolve(coupon);
                        });
                    })];
            });
        });
    };
    BookingProcessor.insertBooking = function (booking) {
        return __awaiter(this, void 0, void 0, function () {
            var obj;
            return __generator(this, function (_a) {
                obj = booking.toObject();
                delete obj.id;
                return [2 /*return*/, new Promise(function (resolve) {
                        rest_1.Rest.postREST('booking/', obj).then(function (data) {
                            if (data[0])
                                booking.fromObject(data[0]);
                            resolve(booking);
                        });
                    })];
            });
        });
    };
    BookingProcessor.deleteBooking = function (booking) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, rest_1.Rest.deleteREST('booking/', { id: booking.id, token: booking.token })];
            });
        });
    };
    BookingProcessor.updateBooking = function (booking) {
        var obj = booking.toObject();
        return new Promise(function (resolve) {
            rest_1.Rest.putREST('booking/', obj).then(function (data) {
                resolve(data != 0);
            });
        });
    };
    return BookingProcessor;
}());
exports.BookingProcessor = BookingProcessor;


/***/ }),

/***/ "./src/bookings/booking.ts":
/*!*********************************!*\
  !*** ./src/bookings/booking.ts ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var database_object_1 = __webpack_require__(/*! ../database/database-object */ "./src/database/database-object.ts");
var utils_1 = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");
exports.BOOKABLE_TIMES = ['19:00:00', '21:00:00'];
var Booking = /** @class */ (function (_super) {
    __extends(Booking, _super);
    function Booking() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Booking.prototype._fromObject = function (obj) {
        this._date = new Date(obj.date);
        this._time = obj.time;
        this._timeLength = Number(obj.time_length);
        this._comment = obj.comment;
        this._restaurant = Number(obj.restaurant_id);
        this._assignedGuide = Number(obj.guide_id);
        this._adults = Number(obj.adults);
        this._children = Number(obj.children);
        this._coupon = obj.coupon;
        this._adultPrice = Number(obj.adultPrice);
        this._childrenPrice = Number(obj.childrenPrice);
        this._couponValue = Number(obj.couponValue);
        this._paidAmount = Number(obj.paidAmount);
        this._paid = Boolean(obj.paid);
        this._name = obj.name;
        this._email = obj.email;
        this._paymentProvider = obj.paymentProvider;
        this._paymentId = obj.paymentId;
        this._currency = obj.currency;
        this._trasactionTimeStamp = new Date(obj.trasactionTimeStamp);
    };
    Booking.prototype._toObject = function () {
        return {
            date: utils_1.Utils.dateToString(this.date),
            time: this.time,
            time_length: this.timeLength,
            comment: this.comment,
            restaurant_id: this.restaurant,
            guide_id: this.assignedGuide,
            adults: this.adults,
            children: this.children,
            coupon: this.coupon,
            adultPrice: this.adultPrice,
            childrenPrice: this.childrenPrice,
            couponValue: this.couponValue,
            paidAmount: this.paidAmount,
            paid: Number(this.paid),
            name: this._name,
            email: this._email,
            paymentProvider: this._paymentProvider,
            paymentId: this._paymentId,
            currency: this._currency,
            trasactionTimeStamp: this._trasactionTimeStamp
        };
    };
    Booking.prototype.setDate = function (date) {
        this._date = date;
        return this;
    };
    Object.defineProperty(Booking.prototype, "date", {
        get: function () {
            return this._date;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setTime = function (time) {
        this._time = time;
        return this;
    };
    Object.defineProperty(Booking.prototype, "time", {
        get: function () {
            return this._time;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setTimeLength = function (time) {
        this._timeLength = time;
        return this;
    };
    Object.defineProperty(Booking.prototype, "timeLength", {
        get: function () {
            return this._timeLength;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setComment = function (comment) {
        this._comment = comment;
        return this;
    };
    Object.defineProperty(Booking.prototype, "comment", {
        get: function () {
            return this._comment;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setRestaurant = function (id) {
        this._restaurant = id;
        return this;
    };
    Object.defineProperty(Booking.prototype, "restaurant", {
        get: function () {
            return this._restaurant;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setAssignedGuide = function (id) {
        this._assignedGuide = id;
        return this;
    };
    Object.defineProperty(Booking.prototype, "assignedGuide", {
        get: function () {
            return this._assignedGuide;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Booking.prototype, "bookedSeats", {
        get: function () {
            return this.adults + this.children;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setAdults = function (val) {
        this._adults = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "adults", {
        get: function () {
            return this._adults;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setChildren = function (val) {
        this._children = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setCoupon = function (val) {
        this._coupon = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "coupon", {
        get: function () {
            return this._coupon;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setAdultPrice = function (val) {
        this._adultPrice = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "adultPrice", {
        get: function () {
            return this._adultPrice;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setChildrenPrice = function (val) {
        this._childrenPrice = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "childrenPrice", {
        get: function () {
            return this._childrenPrice;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setCouponValue = function (val) {
        this._couponValue = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "couponValue", {
        get: function () {
            return this._couponValue;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setPaidAmount = function (val) {
        this._paidAmount = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "paidAmount", {
        get: function () {
            return this._paidAmount;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setPaid = function (val) {
        this._paid = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "paid", {
        get: function () {
            return this._paid;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setName = function (val) {
        this._name = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "name", {
        get: function () {
            return this._name;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setEmail = function (val) {
        this._email = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "email", {
        get: function () {
            return this._email;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setPaymentProvider = function (val) {
        this._paymentProvider = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "paymentProvider", {
        get: function () {
            return this._paymentProvider;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setPaymentId = function (val) {
        this._paymentId = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "paymentId", {
        get: function () {
            return this._paymentId;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setCurrency = function (val) {
        this._currency = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "currency", {
        get: function () {
            return this._currency;
        },
        enumerable: true,
        configurable: true
    });
    Booking.prototype.setTrasactionTimeStamp = function (val) {
        this._trasactionTimeStamp = val;
        return this;
    };
    Object.defineProperty(Booking.prototype, "trasactionTimeStamp", {
        get: function () {
            return this._trasactionTimeStamp;
        },
        enumerable: true,
        configurable: true
    });
    return Booking;
}(database_object_1.DatabaseObject));
exports.Booking = Booking;


/***/ }),

/***/ "./src/bookings/coupon.ts":
/*!********************************!*\
  !*** ./src/bookings/coupon.ts ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var database_object_1 = __webpack_require__(/*! ../database/database-object */ "./src/database/database-object.ts");
var utils_1 = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");
var Coupon = /** @class */ (function (_super) {
    __extends(Coupon, _super);
    function Coupon() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Coupon.prototype.isValid = function () {
        if (this.id < 0)
            return false;
        if (utils_1.Utils.isInvalid(this._validUntil))
            return true;
        var today = new Date(Date.now());
        today.setHours(0);
        return this._validUntil >= today;
    };
    Coupon.prototype.discount = function (basePrice) {
        if (!this.isValid())
            return 0;
        if (this._valueType !== 'percent') {
            return this._value;
        }
        else if (basePrice === undefined) {
            throw new Error('Error: To calculate absoluteValue of percent a base price as parameter should be passed');
        }
        return basePrice * this._value / 100;
    };
    Coupon.prototype._toObject = function () {
        return {
            code: this._code,
            validUntil: utils_1.Utils.dateToString(this._validUntil),
            value: this._value,
            valueType: this._valueType,
            commission: this._commission,
            commisionistId: this._commisionistId
        };
    };
    Coupon.prototype._fromObject = function (obj) {
        this._code = obj.code;
        this._validUntil = new Date(obj.validUntil);
        this._value = obj.value;
        this._valueType = obj.valueType;
        this._commission = obj.commission;
        this._commisionistId = obj.commisionistId;
    };
    return Coupon;
}(database_object_1.DatabaseObject));
exports.Coupon = Coupon;


/***/ }),

/***/ "./src/bookings/guide.ts":
/*!*******************************!*\
  !*** ./src/bookings/guide.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var database_object_1 = __webpack_require__(/*! ../database/database-object */ "./src/database/database-object.ts");
var utils_1 = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");
exports.MAX_SEATS_PER_GUIDE = 6;
var Guide = /** @class */ (function (_super) {
    __extends(Guide, _super);
    function Guide() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Guide.prototype.maxSeats = function () {
        if (this._id >= 0) {
            return exports.MAX_SEATS_PER_GUIDE;
        }
        else {
            return 0;
        }
    };
    ;
    Guide.prototype._toObject = function () {
        return {
            name: this._name,
            score: this._score,
            phone: this._phone,
            email: this._email,
            lineId: this._lineId,
            paypal: this._paypal
        };
    };
    Guide.prototype._fromObject = function (obj) {
        this._name = obj.name;
        this._score = obj.score;
        this._phone = obj.phone;
        this._email = obj.email;
        this._lineId = obj.line_id;
        this._paypal = obj.paypal;
    };
    return Guide;
}(database_object_1.DatabaseObject));
exports.Guide = Guide;
var FreeGuide = /** @class */ (function (_super) {
    __extends(FreeGuide, _super);
    function FreeGuide() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FreeGuide.prototype.setDate = function (date) {
        this._date = date;
        return this;
    };
    Object.defineProperty(FreeGuide.prototype, "date", {
        get: function () {
            return this._date;
        },
        enumerable: true,
        configurable: true
    });
    FreeGuide.prototype._toObject = function () {
        var obj = _super.prototype._toObject.call(this);
        obj.date = utils_1.Utils.dateToString(this._date);
        return obj;
    };
    FreeGuide.prototype._fromObject = function (obj) {
        _super.prototype._fromObject.call(this, obj);
        this._date = new Date(obj.date);
    };
    return FreeGuide;
}(Guide));
exports.FreeGuide = FreeGuide;


/***/ }),

/***/ "./src/bookings/holiday.ts":
/*!*********************************!*\
  !*** ./src/bookings/holiday.ts ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var database_object_1 = __webpack_require__(/*! ../database/database-object */ "./src/database/database-object.ts");
var utils_1 = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");
var Holiday = /** @class */ (function (_super) {
    __extends(Holiday, _super);
    function Holiday() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Holiday.prototype._toObject = function () {
        return {
            id: this._id,
            date: utils_1.Utils.dateToString(this._date)
        };
    };
    Holiday.prototype._fromObject = function (obj) {
        this._date = new Date(obj.date);
    };
    Object.defineProperty(Holiday.prototype, "date", {
        get: function () {
            return this._date;
        },
        set: function (date) {
            this._date = date;
        },
        enumerable: true,
        configurable: true
    });
    return Holiday;
}(database_object_1.DatabaseObject));
exports.Holiday = Holiday;


/***/ }),

/***/ "./src/bookings/restaurant.ts":
/*!************************************!*\
  !*** ./src/bookings/restaurant.ts ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var database_object_1 = __webpack_require__(/*! ../database/database-object */ "./src/database/database-object.ts");
var Restaurant = /** @class */ (function (_super) {
    __extends(Restaurant, _super);
    function Restaurant() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Restaurant.prototype._fromObject = function (p) {
        this._name = p.name;
        this._adultPrice = p.adultPrice;
        this._childrenPrice = p.childrenPrice;
        this._description = p.description;
        this._excerpt = p.excerpt;
        this._foodTypes = p.foodTypes;
        this._services = p.services;
        this._dishSpecials = p.dishSpecials;
        this._valoration = p.valoration;
        this._numberOfReviews = p.numberOfReviews;
        this._includes = p.includes;
        this._excludes = p.excludes;
        this._phone = p.phone;
        this._staffNames = p.staffNames;
        this._address = p.address;
        this._googleMaps = p.googleMaps;
        this._images = p.images;
        this._paypal = p.paypal;
    };
    Restaurant.prototype._toObject = function () {
        return {
            name: this._name,
            adultPrice: this._adultPrice,
            childrenPrice: this._childrenPrice,
            description: this._description,
            excerpt: this._excerpt,
            foodTypes: this._foodTypes,
            services: this._services,
            dishSpecials: this._dishSpecials,
            valoration: this._valoration,
            numberOfReviews: this._numberOfReviews,
            includes: this._includes,
            excludes: this._excludes,
            phone: this._phone,
            staffNames: this._staffNames,
            address: this._address,
            googleMaps: this._googleMaps,
            images: this._images,
            paypal: this._paypal
        };
    };
    Restaurant.prototype.setChildrenPrice = function (val) {
        this._childrenPrice = val;
        return this;
    };
    Object.defineProperty(Restaurant.prototype, "childrenPrice", {
        get: function () {
            return this._childrenPrice;
        },
        enumerable: true,
        configurable: true
    });
    Restaurant.prototype.setAdultPrice = function (val) {
        this._adultPrice = val;
        return this;
    };
    Object.defineProperty(Restaurant.prototype, "adultPrice", {
        get: function () {
            return this._adultPrice;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Restaurant.prototype, "name", {
        get: function () {
            return this._name;
        },
        enumerable: true,
        configurable: true
    });
    return Restaurant;
}(database_object_1.DatabaseObject));
exports.Restaurant = Restaurant;


/***/ }),

/***/ "./src/database/database-object.ts":
/*!*****************************************!*\
  !*** ./src/database/database-object.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var DatabaseObject = /** @class */ (function () {
    function DatabaseObject(id) {
        this._id = id;
    }
    DatabaseObject.prototype.setId = function (id) {
        this._id = id;
    };
    Object.defineProperty(DatabaseObject.prototype, "id", {
        get: function () {
            return this._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DatabaseObject.prototype, "token", {
        get: function () {
            return this._token;
        },
        enumerable: true,
        configurable: true
    });
    DatabaseObject.prototype.fromObject = function (p) {
        if (p.id)
            this._id = Number(p.id);
        if (p.token)
            this._token = p.token;
        this._fromObject(p);
    };
    DatabaseObject.prototype.toObject = function () {
        var obj = this._toObject();
        obj.id = this._id;
        obj.token = this._token;
        return obj;
    };
    return DatabaseObject;
}());
exports.DatabaseObject = DatabaseObject;


/***/ }),

/***/ "./src/database/rest.ts":
/*!******************************!*\
  !*** ./src/database/rest.ts ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Rest = /** @class */ (function () {
    function Rest() {
    }
    Rest.objectToQueryString = function (obj) {
        return '?' + Object.keys(obj)
            .map(function (k) {
            return encodeURIComponent(k) + '=' + encodeURIComponent(obj[k]);
        })
            .join('&');
    };
    Rest.getMonthPeriod = function (endpoint, date, queryObject) {
        var year_month = date.slice(0, 8);
        var minDate = year_month + '01';
        var maxDate = year_month + '31';
        queryObject['minDate'] = minDate;
        queryObject['maxDate'] = maxDate;
        return Rest.getREST(endpoint, queryObject);
    };
    Rest.buildList = function (data, createInstance) {
        var list = [];
        var i = 0;
        while (data[i]) {
            if (data[i].id) {
                var element = createInstance();
                element.fromObject(data[i]);
                list.push(element);
            }
            i++;
        }
        return list;
    };
    Rest.getREST = function (endpointCommand, queryObject) {
        var fullURL = Rest._url + endpointCommand + this.objectToQueryString(queryObject);
        return new Promise(function (resolve) {
            fetch(fullURL).then(function (resp) {
                var data = resp.json();
                resolve(data);
            }).catch(function (error) {
                throw (new Error('Kinlen Booking System: ' + error.message));
            });
        });
    };
    Rest.postREST = function (endpointCommand, dataObject) {
        var fullURL = Rest._url + endpointCommand;
        return new Promise(function (resolve) {
            fetch(fullURL, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(dataObject)
            }).then(function (resp) {
                resolve(resp.json());
            });
        });
    };
    Rest.putREST = function (endpointCommand, dataObject) {
        var fullURL = Rest._url + endpointCommand;
        return new Promise(function (resolve) {
            fetch(fullURL, {
                method: 'PUT',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(dataObject)
            }).then(function (resp) {
                resolve(resp.json());
            });
        });
    };
    Rest.deleteREST = function (endpointCommand, queryObject) {
        var fullURL = Rest._url + endpointCommand + this.objectToQueryString(queryObject);
        return new Promise(function (resolve) {
            fetch(fullURL, {
                method: 'DELETE',
            }).then(function (resp) { return resolve(resp.json()); });
        });
    };
    Rest._url = '/wp-json/kinlen/';
    return Rest;
}());
exports.Rest = Rest;


/***/ }),

/***/ "./src/frontend/booking-form-manager.ts":
/*!**********************************************!*\
  !*** ./src/frontend/booking-form-manager.ts ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var booking_mapper_1 = __webpack_require__(/*! ../bookings/booking-mapper */ "./src/bookings/booking-mapper.ts");
var observer_1 = __webpack_require__(/*! ../utils/observer */ "./src/utils/observer.ts");
var guide_1 = __webpack_require__(/*! ../bookings/guide */ "./src/bookings/guide.ts");
var form_submiter_1 = __webpack_require__(/*! ./form-submiter */ "./src/frontend/form-submiter.ts");
exports.initialState = {
    adults: 0,
    children: 0,
    date: '',
    time: '',
    coupon: '',
    name: '',
    email: '',
    comment: '',
};
var BookingFormManager = /** @class */ (function (_super) {
    __extends(BookingFormManager, _super);
    function BookingFormManager(formElementId, initialState) {
        var _this = _super.call(this, initialState) || this;
        _this._submiter = new form_submiter_1.FormSubmiter(_this, document.getElementById(formElementId));
        return _this;
    }
    BookingFormManager.prototype.rawBooking = function () {
        var booking = this.state;
        booking.date = new Date(this.state.date);
        booking.time = this.state.time + ':00';
        booking.restaurant_id = this._mapper.restaurantId;
        return booking;
    };
    BookingFormManager.prototype.setRestaurant = function (restaurantId) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this._mapper = new booking_mapper_1.BookingMapper(restaurantId);
                        return [4 /*yield*/, this._mapper.buildBookingMapCache(new Date())];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, this];
                }
            });
        });
    };
    BookingFormManager.prototype.refreshBookingMap = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this._mapper.buildBookingMapCache(new Date())];
                    case 1:
                        _a.sent();
                        this.resetDate();
                        return [2 /*return*/];
                }
            });
        });
    };
    BookingFormManager.prototype.registerSelectElements = function (elements) {
        var _this = this;
        for (var name_1 in elements) {
            var observable = new observer_1.ObservableSelect(name_1, elements[name_1], 0);
            this.registerObservable(observable);
        }
        this.observables.adults.onChange = function () { return _this.adultsChanged(); };
        this.observables.children.onChange = function () { return _this.resetDate(); };
        return this;
    };
    BookingFormManager.prototype.registerStringElements = function (elements) {
        for (var name_2 in elements) {
            this.registerObservable(new observer_1.ObservableField(name_2, elements[name_2], ''));
        }
        return this;
    };
    BookingFormManager.prototype.registerRadioGroup = function (name, radioButtons) {
        var radioGroup = new observer_1.ObservableRadioGroup(name, '');
        for (var name_3 in radioButtons) {
            radioGroup.addRadioButton(new observer_1.ObservableRadio(name_3, radioButtons[name_3]));
        }
        this.registerObservable(radioGroup);
        return this;
    };
    BookingFormManager.prototype.setCalendar = function (calendar) {
        var _this = this;
        calendar.config.disableMobile = true;
        calendar.config.onMonthChange = [function (_selectedDates, _dateStr, instance) { return _this.updateDates(instance); }];
        calendar.config.onOpen = [function (_selectedDates, _dateStr, instance) { return _this.updateDates(instance); }];
        calendar.config.onChange = [function (selectedDates) { return _this.dateSet(selectedDates[0]); }];
        this.observables.date.onChange = function () { return _this.dateSet(new Date(_this.state.date)); };
        this.observables.date.element.readOnly = true;
        return this;
    };
    BookingFormManager.prototype.setSummaryElement = function (element) {
        this._submiter.setSummaryElement(document.getElementById(element));
        return this;
    };
    BookingFormManager.prototype.registerPaymentProvider = function (paymentProvider) {
        this._submiter.registerPaymentProvider(paymentProvider);
        return this;
    };
    BookingFormManager.prototype.adultsChanged = function () {
        var children = this.observables.children;
        var options = [];
        var maxChildren = guide_1.MAX_SEATS_PER_GUIDE - this.state.adults + 1;
        for (var i = 0; i < maxChildren; i++) {
            options[i] = String(i);
        }
        children.setOptions(options);
        this.resetDate();
    };
    BookingFormManager.prototype.updateDates = function (instance) {
        return __awaiter(this, void 0, void 0, function () {
            var date, map;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        date = new Date(instance.currentYear, instance.currentMonth, 1);
                        return [4 /*yield*/, this._mapper.getUnavailableDays(date, this.requiredSeats())];
                    case 1:
                        map = _a.sent();
                        instance.config.disable = map;
                        console.log(map);
                        instance.redraw();
                        return [2 /*return*/];
                }
            });
        });
    };
    BookingFormManager.prototype.radioButtons = function () {
        return this.observables.time.radioButtons;
    };
    BookingFormManager.prototype.dateSet = function (date) {
        var _this = this;
        var first = true;
        this.radioButtons().forEach(function (timeOpt) { return __awaiter(_this, void 0, void 0, function () {
            var isAvailable;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this._mapper.isTimeSlotAvailable(date, timeOpt.name + ':00', this.requiredSeats())];
                    case 1:
                        isAvailable = _a.sent();
                        isAvailable ? timeOpt.show() : timeOpt.hide();
                        if (first && isAvailable) {
                            timeOpt.value = true;
                            first = false;
                        }
                        return [2 /*return*/];
                }
            });
        }); });
        //		this.observables.name.focus();
    };
    BookingFormManager.prototype.resetDate = function () {
        this.setState({ date: '' });
        this.radioButtons().forEach(function (timeOpt) { return timeOpt.show(); });
        this.radioButtons()[0].value = true;
    };
    BookingFormManager.prototype.requiredSeats = function () {
        return this.state.adults + this.state.children;
    };
    return BookingFormManager;
}(observer_1.Observer));
exports.BookingFormManager = BookingFormManager;


/***/ }),

/***/ "./src/frontend/form-submiter.ts":
/*!***************************************!*\
  !*** ./src/frontend/form-submiter.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var booking_processor_1 = __webpack_require__(/*! ../bookings/booking-processor */ "./src/bookings/booking-processor.ts");
var utils_1 = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");
var payment_provider_1 = __webpack_require__(/*! ../payment-providers/payment-provider */ "./src/payment-providers/payment-provider.ts");
var FormSubmiter = /** @class */ (function () {
    function FormSubmiter(formManager, formElement) {
        var _this = this;
        this._paymentProviders = [];
        this._formManager = formManager;
        this._formElement = formElement;
        this._formElement.onsubmit = function () { return _this.formSubmited(); };
    }
    FormSubmiter.prototype.setSummaryElement = function (element) {
        this._summary = element;
    };
    FormSubmiter.prototype.registerPaymentProvider = function (paymentProvider) {
        var _this = this;
        paymentProvider.onError = function (msg) { return _this.paymentError(msg); };
        paymentProvider.onCancel = function () { return _this.paymentCancelled(); };
        paymentProvider.onAuthorize = function (data) { return _this.paymentAuthorized(data); };
        paymentProvider.onStartPayment = function () { return _this.startPayment(); };
        this._paymentProviders.push(paymentProvider);
    };
    FormSubmiter.prototype.formSubmited = function () {
        return __awaiter(this, void 0, void 0, function () {
            var container, booking, validBooking, e_1;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        container = document.getElementById(this._paymentProviders[0].anchorElement);
                        booking = this._formManager.rawBooking();
                        this._processor = new booking_processor_1.BookingProcessor(booking);
                        validBooking = false;
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this._processor.validateBooking(true)];
                    case 2:
                        validBooking = _a.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        e_1 = _a.sent();
                        this.paymentError(e_1.message);
                        return [3 /*break*/, 4];
                    case 4:
                        if (!validBooking) return [3 /*break*/, 6];
                        return [4 /*yield*/, this.showSummary(this._processor)];
                    case 5:
                        _a.sent();
                        if (container) {
                            this._paymentProviders.forEach(function (provider) {
                                provider.setBookingProcessor(_this._processor);
                                provider.renderButton();
                            });
                        }
                        else
                            throw new Error('Paypal container element not found');
                        _a.label = 6;
                    case 6:
                        container.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start',
                            inline: 'nearest'
                        });
                        return [2 /*return*/, new Promise(function (resolve) {
                                setTimeout(function () {
                                    var elementorSuccess = _this._formElement.getElementsByClassName('elementor-message-success').item(0);
                                    if (!validBooking && elementorSuccess)
                                        elementorSuccess.style.display = 'none';
                                    _this.refillFields(booking);
                                    resolve();
                                }, 50);
                            })];
                }
            });
        });
    };
    FormSubmiter.prototype.startPayment = function () {
        return __awaiter(this, void 0, void 0, function () {
            var tempBooking;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this._processor.insertTempBooking()];
                    case 1:
                        tempBooking = _a.sent();
                        if (!tempBooking) {
                            this.paymentError(payment_provider_1.PaymentErrors.BOOKING_NOT_AVAILABLE);
                        }
                        return [2 /*return*/, tempBooking != null];
                }
            });
        });
    };
    FormSubmiter.prototype.paymentAuthorized = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            var booking;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this._processor.persistTempBooking(data)];
                    case 1:
                        booking = _a.sent();
                        if (!booking) {
                            this.paymentError(payment_provider_1.PaymentErrors.BOOKING_NOT_UPDATED);
                            return [2 /*return*/, false];
                        }
                        window.location.assign('/thanks/?id=' + booking.id);
                        return [2 /*return*/, true];
                }
            });
        });
    };
    FormSubmiter.prototype.paymentCancelled = function () {
        return __awaiter(this, void 0, void 0, function () {
            var result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.showPaymentError(payment_provider_1.PaymentErrors.PAYMENT_CANCELLED);
                        return [4 /*yield*/, this._processor.deleteTempBooking()];
                    case 1:
                        result = _a.sent();
                        if (!result) {
                            throw new Error('Unable to delete temp booking');
                        }
                        return [2 /*return*/, result];
                }
            });
        });
    };
    FormSubmiter.prototype.paymentError = function (errorText) {
        this._formManager.refreshBookingMap();
        this.showPaymentError(errorText);
    };
    FormSubmiter.prototype.showPaymentError = function (errorText) {
        var element = [];
        element.push('<h3>An error occurred while processing you booking</h3>');
        element.push('<p style="color:red;">' + errorText + '</p>');
        element.push('<h4>Please, review the details of your booking</h4>');
        this._summary.innerHTML = element.join('\n');
    };
    FormSubmiter.prototype.showSummary = function (p) {
        return __awaiter(this, void 0, void 0, function () {
            var b, restaurant, element, _a, _b, _c;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0: return [4 /*yield*/, p.booking()];
                    case 1:
                        b = _d.sent();
                        return [4 /*yield*/, p.restaurant()];
                    case 2:
                        restaurant = _d.sent();
                        element = [];
                        element.push('	<h3>Please, review the details of your booking</h3>');
                        element.push('		<p id="kl-summary-generic-data">You will book on ' + b.date.toDateString() + ' at ' + b.time.slice(0, 5) + ' in restaurant ' + restaurant.name + '</p>');
                        element.push('		<p id="kl-summary-email">In case we need to contact you, we will send an email to: ' + b.email + '</p>');
                        element.push('		<p id="kl-summary-adults">' + b.adults + ' adults at ฿' + b.adultPrice + ' each</p>');
                        if (b.children) {
                            element.push('	<p id="kl-summary-children">' + b.children + ' children at ฿' + b.childrenPrice + ' each</p>');
                        }
                        if (b.couponValue) {
                            element.push('	<p id="kl-summary-discount">Discount coupon. Value ฿' + b.couponValue + '</p>');
                        }
                        _b = (_a = element).push;
                        _c = '	<h4 id="kl-summary-total-to-pay">Total to pay: ฿';
                        return [4 /*yield*/, p.totalToPay()];
                    case 3:
                        _b.apply(_a, [_c + (_d.sent()) + '</h4>']);
                        this._summary.innerHTML = element.join('\n');
                        return [2 /*return*/];
                }
            });
        });
    };
    FormSubmiter.prototype.refillFields = function (booking) {
        this._formManager.observables.adults.element.value = String(booking.adults);
        this._formManager.observables.children.element.value = String(booking.children);
        this._formManager.observables.date.element.value = String(utils_1.Utils.isInvalid(booking.date) ? '' : booking.date.toISOString().slice(0, 10));
        this._formManager.observables.time.checkRadioButtonElements(booking.time.slice(0, 5));
        this._formManager.observables.name.element.value = booking.name;
        this._formManager.observables.email.element.value = booking.email;
        this._formManager.observables.coupon.element.value = booking.coupon;
        this._formManager.observables.comment.element.value = booking.comment;
    };
    return FormSubmiter;
}());
exports.FormSubmiter = FormSubmiter;


/***/ }),

/***/ "./src/index.ts":
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var booking_form_manager_1 = __webpack_require__(/*! ./frontend/booking-form-manager */ "./src/frontend/booking-form-manager.ts");
var paypal_1 = __webpack_require__(/*! ./payment-providers/paypal */ "./src/payment-providers/paypal.ts");
document.addEventListener('DOMContentLoaded', function () {
    //  document.getElementById( 'bookingButton' ).onclick = ()=> openTab( 'detail-tab', 'Book Now' );
    var bookingForm = document.getElementById('kl-booking-form');
    if (bookingForm) {
        flatpickr(document.getElementById('form-field-kl-booking-date'), { disableMobile: true });
        document.getElementById('form-field-kl-booking-date').setAttribute('autocomplete', 'off');
        setupBookingFormManager();
    }
}, false);
function setupBookingFormManager() {
    return __awaiter(this, void 0, void 0, function () {
        var postId, bookingFormManager;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    postId = document.getElementById('kl-post-id').firstElementChild.firstElementChild.innerHTML;
                    return [4 /*yield*/, new booking_form_manager_1.BookingFormManager('kl-booking-form', booking_form_manager_1.initialState)
                            .registerSelectElements({
                            adults: 'form-field-kl-adults',
                            children: 'form-field-kl-children',
                        })
                            .registerStringElements({
                            date: 'form-field-kl-booking-date',
                            name: 'form-field-kl-name',
                            email: 'form-field-kl-email',
                            coupon: 'form-field-kl-coupon',
                            comment: 'form-field-kl-requirements'
                        })
                            .registerRadioGroup('time', {
                            '19:00': 'form-field-kl-booking-time-0',
                            '21:00': 'form-field-kl-booking-time-1'
                        })
                            .setCalendar(document.getElementById('form-field-kl-booking-date')._flatpickr)
                            .setSummaryElement('kl-summary-box')
                            .registerPaymentProvider(new paypal_1.Paypal('paypal-button-container'))];
                case 1:
                    bookingFormManager = _a.sent();
                    return [2 /*return*/, bookingFormManager.setRestaurant(Number(postId))];
            }
        });
    });
}
exports.setupBookingFormManager = setupBookingFormManager;
/**
 * @description Opens a tab from the Elementor Tab widget
 * @param tabWidgetId is the id of the whole Elementor Tab widget. You can
 *                     customize in Elementor's advanced settings
 * @param tabToOpen identifies the tab number or tab title to openTab
 */
// function openTab( _tabWidgetId, _tabToOpen ) {
//   var tabObject = jQuery( '#' + tabWidgetId );
//   var activeObject =  tabObject.find( '.elementor-active' );
//   if (typeof tabToOpen === 'string' || tabToOpen instanceof String) {
//     tabToOpen = tabObject.find( '.elementor-tab-title' ).filter( ':contains("' + tabToOpen + '")' ).attr('data-tab');
//   }
//   var tabObjectToOpen = tabObject.find( "[data-tab='" + tabToOpen + "']" );
//   activeObject.removeClass( 'elementor-active' );
//   tabObjectToOpen.addClass('elementor-active');
//   activeObject.filter('.elementor-tab-content').hide();
//   tabObjectToOpen.filter('.elementor-tab-content').show();
// }


/***/ }),

/***/ "./src/payment-providers/payment-provider.ts":
/*!***************************************************!*\
  !*** ./src/payment-providers/payment-provider.ts ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentErrors = {
    BOOKING_NOT_AVAILABLE: 'The selected booking slot is no longer available. Please select another date or time slot or try later.',
    PAYMENT_CANCELLED: 'The payment has not been fulfilled. Please try again to guaranty your booking.',
    PAYMENT_ERROR: 'There has been an error during the payment process. Please try again to guaranty your booking.',
    BOOKING_NOT_UPDATED: 'We are sorry. At this time we cannot complete the booking process due to technical reason. We will contact you by email to refund your money. Sorry for the inconvenience.'
};
var PaymentProvider = /** @class */ (function () {
    function PaymentProvider(anchorElement) {
        this._anchorElement = anchorElement;
    }
    Object.defineProperty(PaymentProvider.prototype, "onStartPayment", {
        get: function () {
            return this._onStartPayment;
        },
        set: function (callBack) {
            this._onStartPayment = callBack;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PaymentProvider.prototype, "onAuthorize", {
        get: function () {
            return this._onAuthorize;
        },
        set: function (callBack) {
            this._onAuthorize = callBack;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PaymentProvider.prototype, "onError", {
        get: function () {
            return this._onError;
        },
        set: function (callBack) {
            this._onError = callBack;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PaymentProvider.prototype, "onCancel", {
        get: function () {
            return this._onCancel;
        },
        set: function (callBack) {
            this._onCancel = callBack;
        },
        enumerable: true,
        configurable: true
    });
    PaymentProvider.prototype.setBookingProcessor = function (processor) {
        this._bookingProcessor = processor;
        return this;
    };
    Object.defineProperty(PaymentProvider.prototype, "bookingProcessor", {
        get: function () {
            return this._bookingProcessor;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PaymentProvider.prototype, "anchorElement", {
        get: function () {
            return this._anchorElement;
        },
        enumerable: true,
        configurable: true
    });
    return PaymentProvider;
}());
exports.PaymentProvider = PaymentProvider;


/***/ }),

/***/ "./src/payment-providers/paypal.ts":
/*!*****************************************!*\
  !*** ./src/payment-providers/paypal.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var paypal = __webpack_require__(/*! paypal-checkout */ "paypal-checkout");
var payment_provider_1 = __webpack_require__(/*! ./payment-provider */ "./src/payment-providers/payment-provider.ts");
var Paypal = /** @class */ (function (_super) {
    __extends(Paypal, _super);
    function Paypal() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Paypal.prototype.payment = function (_data, actions) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, obj, _b;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        _a = this.onStartPayment;
                        if (!_a) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.onStartPayment()];
                    case 1:
                        _a = (_c.sent());
                        _c.label = 2;
                    case 2:
                        if (!_a) return [3 /*break*/, 4];
                        _b = {};
                        return [4 /*yield*/, this.getPayment()];
                    case 3:
                        obj = (_b.payment = _c.sent(),
                            _b.experience = {
                                input_fields: {
                                    no_shipping: 1
                                }
                            },
                            _b);
                        return [2 /*return*/, actions.payment.create(obj)];
                    case 4: return [2 /*return*/, false];
                }
            });
        });
    };
    Paypal.prototype.autorized = function (_data, actions) {
        var _this = this;
        return actions.payment.execute()
            .then(function (data) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(data.state === 'approved' && this.onAuthorize)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.onAuthorize({
                                paymentId: data.id,
                                paymentProvider: data.payer.payment_method,
                                paidAmount: Number(data.transactions[0].amount.total),
                                currency: data.transactions[0].amount.currency
                            })];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2:
                        if (data.state !== 'approved' && this.onError)
                            this.onError(payment_provider_1.PaymentErrors.PAYMENT_ERROR);
                        return [2 /*return*/];
                }
            });
        }); });
    };
    Paypal.prototype.cancelled = function (_data, _actions) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                if (this.onCancel) {
                    return [2 /*return*/, this.onCancel()];
                }
                else {
                    return [2 /*return*/, false];
                }
                return [2 /*return*/];
            });
        });
    };
    Paypal.prototype.error = function (err) {
        if (this.onError)
            this.onError(err);
    };
    Paypal.prototype.renderButton = function () {
        var _this = this;
        var element = document.getElementById(this._anchorElement);
        while (element.firstChild)
            element.removeChild(element.firstChild);
        return new Promise(function (resolve) {
            var cfg = _this.buttonConfig(resolve);
            paypal.Button.render(cfg, '#' + _this._anchorElement).then(function () { return resolve(); });
        });
    };
    Paypal.prototype.buttonConfig = function (resolve) {
        var _this = this;
        return {
            env: 'sandbox',
            locale: 'en_US',
            style: this.buttonStyle(),
            funding: this.funding(),
            // Enable Pay Now checkout flow (optional)
            commit: true,
            client: this.secrets(),
            payment: function (data, actions) { return _this.payment(data, actions); },
            onAuthorize: function (data, actions) { return _this.autorized(data, actions); },
            onCancel: function (data, actions) { return _this.cancelled(data, actions); },
            onError: this.error,
            onRender: function () { return resolve(); }
        };
    };
    Paypal.prototype.secrets = function () {
        return {
            sandbox: 'AYrSBefLwtleGdIfw-g2SDZBu0ejMEPxLgFVG4aldURXvuhB8yCahg8Si45psKTwzk0gYJV66dkXvwsN',
            production: 'AS7fAX4ZytJ-D9m0IkJ5DQYSiJO0TN9l9600ehFoNCIoC0WVmpSmcvMQSLz0OZ9R67uYlW-gorz-1IDY'
        };
    };
    Paypal.prototype.funding = function () {
        // Options:
        // - paypal.FUNDING.CARD
        // - paypal.FUNDING.CREDIT
        // - paypal.FUNDING.ELV
        return {
            allowed: [
                paypal.FUNDING.CARD,
            ],
            disallowed: [
                paypal.FUNDING.CREDIT
            ]
        };
    };
    Paypal.prototype.buttonStyle = function () {
        return {
            layout: 'vertical',
            size: 'responsive',
            shape: 'rect',
            color: 'gold' // gold | blue | silver | white | black
        };
    };
    Paypal.prototype.getPayment = function () {
        return __awaiter(this, void 0, void 0, function () {
            var total, items, restaurant;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.bookingProcessor.totalToPay()];
                    case 1:
                        total = _a.sent();
                        return [4 /*yield*/, this.getItemList()];
                    case 2:
                        items = _a.sent();
                        return [4 /*yield*/, this.bookingProcessor.restaurant()];
                    case 3:
                        restaurant = _a.sent();
                        return [2 /*return*/, {
                                payer: {
                                    payment_method: 'paypal'
                                },
                                intent: 'sale',
                                transactions: [{
                                        amount: {
                                            total: total.toString(),
                                            currency: 'THB',
                                        },
                                        description: 'Your booking for ' + restaurant.name,
                                        //invoice_number: '12345', Insert a unique invoice number
                                        item_list: {
                                            items: items,
                                        }
                                    }],
                            }];
                }
            });
        });
    };
    Paypal.prototype.getItemList = function () {
        return __awaiter(this, void 0, void 0, function () {
            var booking, items, adultItem, childrenItem, discount, discountItem;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.bookingProcessor.booking()];
                    case 1:
                        booking = _a.sent();
                        items = [];
                        adultItem = {
                            currency: 'THB',
                            name: 'Adults',
                            price: booking.adultPrice.toString(),
                            quantity: booking.adults
                        };
                        items.push(adultItem);
                        if (booking.children) {
                            childrenItem = {
                                currency: 'THB',
                                name: 'Children',
                                price: booking.childrenPrice.toString(),
                                quantity: booking.children
                            };
                            items.push(childrenItem);
                        }
                        if (booking.couponValue) {
                            discount = -booking.couponValue;
                            discountItem = {
                                currency: 'THB',
                                name: 'Discount Coupon',
                                price: discount.toString(),
                                quantity: 1
                            };
                            items.push(discountItem);
                        }
                        return [2 /*return*/, items];
                }
            });
        });
    };
    return Paypal;
}(payment_provider_1.PaymentProvider));
exports.Paypal = Paypal;


/***/ }),

/***/ "./src/utils/observer.ts":
/*!*******************************!*\
  !*** ./src/utils/observer.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var ObserverBase = /** @class */ (function () {
    function ObserverBase() {
    }
    return ObserverBase;
}());
var Observer = /** @class */ (function (_super) {
    __extends(Observer, _super);
    function Observer(initialState) {
        var _this = _super.call(this) || this;
        _this._observables = {};
        _this._state = initialState; //should be past with initilized values so it remembers the type
        return _this;
    }
    Observer.prototype.registerObservable = function (observable) {
        this._observables[observable.name] = observable.setObserver(this);
        return this;
    };
    Observer.prototype.setState = function (val) {
        for (var key in val) {
            if (this._state[key] != val[key]) {
                this._observables[key].setValue(val[key]);
            }
        }
    };
    Object.defineProperty(Observer.prototype, "state", {
        get: function () {
            return this._state;
        },
        enumerable: true,
        configurable: true
    });
    Observer.prototype.change = function (propName, value) {
        this._state[propName] = value;
    };
    Object.defineProperty(Observer.prototype, "observables", {
        get: function () {
            return this._observables;
        },
        enumerable: true,
        configurable: true
    });
    return Observer;
}(ObserverBase));
exports.Observer = Observer;
var ObservableBase = /** @class */ (function () {
    function ObservableBase() {
    }
    ObservableBase.prototype.setObserver = function (observer) {
        this._observer = observer;
        this._change();
        return this;
    };
    Object.defineProperty(ObservableBase.prototype, "observer", {
        get: function () {
            return this._observer;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ObservableBase.prototype, "name", {
        get: function () {
            return this._name;
        },
        set: function (val) {
            this._name = val;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ObservableBase.prototype, "element", {
        get: function () {
            return this._element;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ObservableBase.prototype, "onChange", {
        get: function () {
            return this._onChange;
        },
        set: function (callBack) {
            this._onChange = callBack;
        },
        enumerable: true,
        configurable: true
    });
    ObservableBase.prototype.hide = function () {
        this._element.style.display = 'none';
    };
    ObservableBase.prototype.show = function () {
        this._element.style.display = 'block';
    };
    ObservableBase.prototype.focus = function () {
        this._element.focus();
    };
    return ObservableBase;
}());
var Observable = /** @class */ (function (_super) {
    __extends(Observable, _super);
    function Observable(name, element, initialValue) {
        var _this = _super.call(this) || this;
        _this._value = initialValue; // to remember type
        _this.name = name;
        _this._element = element ? document.getElementById(element) : null;
        if (element && !_this._element) {
            throw new Error('Error: Element ' + element + ' not found');
        }
        if (_this._element) {
            _this._element.onchange = function () { return _this._change(); };
        }
        return _this;
    }
    Object.defineProperty(Observable.prototype, "value", {
        get: function () {
            return this.getValue();
        },
        set: function (val) {
            this.setValue(val);
            this._change();
        },
        enumerable: true,
        configurable: true
    });
    Observable.prototype._change = function () {
        this._value = this.value;
        if (this.observer)
            this.observer.change(this.name, this._value);
        if (this.onChange)
            this.onChange();
    };
    Observable.prototype.convert = function (val) {
        if (typeof (this._value) === 'string') {
            return String(val);
        }
        else {
            return Number(val);
        }
    };
    return Observable;
}(ObservableBase));
exports.Observable = Observable;
var ObservableField = /** @class */ (function (_super) {
    __extends(ObservableField, _super);
    function ObservableField() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ObservableField.prototype.setValue = function (val) {
        this.element.value = String(val);
    };
    ObservableField.prototype.getValue = function () {
        return this.convert(this.element.value);
    };
    return ObservableField;
}(Observable));
exports.ObservableField = ObservableField;
var ObservableRadio = /** @class */ (function (_super) {
    __extends(ObservableRadio, _super);
    function ObservableRadio(name, element) {
        return _super.call(this, name, element, null) || this;
    }
    ObservableRadio.prototype.setRadioGroup = function (radioGroup) {
        this._radioGroup = radioGroup;
    };
    ObservableRadio.prototype._change = function () {
        _super.prototype._change.call(this);
        if (this._radioGroup) {
            if (this._radioGroup.observer)
                this._radioGroup.observer.change(this._radioGroup.name, this._radioGroup.value);
            if (this._radioGroup.onChange)
                this._radioGroup.onChange();
        }
    };
    ObservableRadio.prototype.hide = function () {
        this._element.parentElement.style.display = 'none';
    };
    ObservableRadio.prototype.show = function () {
        this._element.parentElement.style.display = 'block';
    };
    ObservableRadio.prototype.setValue = function (val) {
        this.element.checked = val;
    };
    ObservableRadio.prototype.getValue = function () {
        return this.convert(this.element.checked);
    };
    return ObservableRadio;
}(Observable));
exports.ObservableRadio = ObservableRadio;
var ObservableSelect = /** @class */ (function (_super) {
    __extends(ObservableSelect, _super);
    function ObservableSelect() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ObservableSelect.prototype.setOptions = function (options) {
        var select = this.element;
        select.options.length = 0;
        options.forEach(function (item) { return select.insertAdjacentHTML('beforeend', '<option>' + item + '</option>'); });
    };
    return ObservableSelect;
}(ObservableField));
exports.ObservableSelect = ObservableSelect;
var ObservableRadioGroup = /** @class */ (function (_super) {
    __extends(ObservableRadioGroup, _super);
    function ObservableRadioGroup(name, initialValue) {
        var _this = _super.call(this, name, '', initialValue) || this;
        _this._radioList = [];
        _this._initialValue = initialValue;
        return _this;
    }
    ObservableRadioGroup.prototype.addRadioButton = function (radio) {
        radio.value = this.value === radio.name;
        radio.setRadioGroup(this);
        this._radioList.push(radio);
    };
    Object.defineProperty(ObservableRadioGroup.prototype, "radioButtons", {
        get: function () {
            return this._radioList;
        },
        enumerable: true,
        configurable: true
    });
    ObservableRadioGroup.prototype.setValue = function (val) {
        this._radioList.forEach(function (item) {
            item.value = item.element.value === String(val);
        });
    };
    ObservableRadioGroup.prototype.getValue = function () {
        var _this = this;
        var value;
        this._radioList.some(function (item) {
            if (item.value) {
                value = _this.convert(item.element.value);
            }
            return item.value;
        });
        return value || this._initialValue;
    };
    ObservableRadioGroup.prototype.checkRadioButtonElements = function (val) {
        this._radioList.forEach(function (item) {
            item.element.checked = item.element.value === String(val);
        });
    };
    Object.defineProperty(ObservableRadioGroup.prototype, "element", {
        get: function () { return null; },
        enumerable: true,
        configurable: true
    });
    ; // not have element
    return ObservableRadioGroup;
}(Observable));
exports.ObservableRadioGroup = ObservableRadioGroup;


/***/ }),

/***/ "./src/utils/utils.ts":
/*!****************************!*\
  !*** ./src/utils/utils.ts ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Utils = /** @class */ (function () {
    function Utils() {
    }
    Utils.dateToString = function (date) {
        var str = String(date.getFullYear()) + '-'
            + Utils.toString(date.getMonth() + 1, 2) + '-'
            + Utils.toString(date.getDate(), 2);
        return str;
    };
    Utils.toString = function (n, leftPad, char) {
        if (char === void 0) { char = '0'; }
        var str = String(n);
        while (str.length < leftPad)
            str = char + str;
        return str;
    };
    Utils.isInvalid = function (date) {
        return isNaN(date.getMilliseconds());
    };
    return Utils;
}());
exports.Utils = Utils;


/***/ }),

/***/ "paypal-checkout":
/*!*************************!*\
  !*** external "paypal" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_paypal_checkout__;

/***/ })

/******/ });
});
//# sourceMappingURL=main.kinlen.js.map